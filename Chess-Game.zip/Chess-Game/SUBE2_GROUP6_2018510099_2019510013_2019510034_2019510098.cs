﻿using System;
using System.Threading;
using System.IO;
namespace project3
{
    class Program
    {
        static int column;
        static int raw;
        //static bool whitechecked = false;
        //static bool blackchecked = false;
        struct ccheckstruct
        {
            public string Name;
            //public int x;
            //public int y;
            public string[,] merhaba;

        }
        struct hint
        {
            public string Name;
            public string[,] hitplayable;

        }
        static void GameBoard()
        {
            //for the visuality of game board
            for (int i = 4; i < 20; i += 2)
            {
                for (int j = 4; j < 44; j += 5)
                {
                    Console.SetCursorPosition(j, i);
                    if ((j % 2 == 0 && (i / 2) % 2 == 0) || (j % 2 == 1 && (i / 2) % 2 == 1))
                    {
                        Console.BackgroundColor = ConsoleColor.White;
                        Console.Write("     ");
                        Console.SetCursorPosition(j, i + 1);
                        Console.Write("     ");
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.Write("     ");
                        Console.SetCursorPosition(j, i + 1);
                        Console.Write("     ");
                    }
                }
            }
            Console.BackgroundColor = ConsoleColor.Black;

            for (int i = 1; i < 9; i++)
            {
                Console.SetCursorPosition(2, i * 2 + 3);
                Console.WriteLine(9 - i);
                Console.SetCursorPosition(i * 5 + 1, 3);
                Console.WriteLine(Convert.ToChar(i + 96));
            }

        }


        static void Main()
        {
            int a1 = 0;
            ccheckstruct[] tarray = new ccheckstruct[3];
            hint[] hintarray = new hint[16];
            string[,] ChessPieces = new string[8, 8]{ { "BR", "BN", "BB", "BQ", "BK", "BB", "BN", "BR" },
                                                       { "Bp", "Bp", "Bp", "Bp", "Bp", "Bp", "Bp", "Bp" },
                                                        {".",   ".",  ".",  ".",  ".",  ".",  ".",  "."},
                                                        {".",   ".",  ".",  ".",  ".",  ".",  ".",  "."},
                                                        {".",   ".",  ".",  ".",  ".",  ".",  ".",  "."},
                                                        {".",   ".",  ".",  ".",  ".",  ".",  ".",  "."},
                                                        { "Wp", "Wp", "Wp", "Wp", "Wp", "Wp", "Wp", "Wp" },
                                                        { "WR", "WN", "WB", "WQ", "WK", "WB", "WN", "WR" } };
            string[,] Playablechess = new string[8, 8];/// seçilen taşın hareket edebileceği yerlerin işaretlendiği dizi
            string[,] chesscheck = new string[8, 8];/// seçilen taşın hareket edebileceği yerlerin işaretlendiği dizi
            bool ccheck = false;
            bool whiteccheck = false;
            bool blackccheck = false;
            int getx = 0, gety = 0;/// hareket eden taşın eski konumunun tutulduğu değişken
            ConsoleKeyInfo cki;
            int cursorx, cursory;
            string value = "";
            bool white = true;

            int sayac2;
            int count_WK = 0, count_WR1 = 0, count_WR2 = 0;
            int count_BK = 0, count_BR1 = 0, count_BR2 = 0;
            string[,] castling_check = new string[8, 8];
            int sayac = 0;
            int counter_hamle = 0;
            string mode;
            int s = 0;
            string[,] filewriter = new string[150, 3];
            do
            {
                Console.WriteLine("Please choose the game mode that you want to play:\n 1)demo mode\n 2)Normal mode \n 3)Easy mode");
                mode = Console.ReadLine();
            } while (mode != "1" && mode != "2" && mode != "3");
            Console.Clear();


            GameBoard();
            reflesh();

            //////////////EKLEME//////////////




            int converter(char a)
            {
                if (a == 'a')
                    return 0;
                if (a == 'b')
                    return 1;
                if (a == 'c')
                    return 2;
                if (a == 'd')
                    return 3;
                if (a == 'e')
                    return 4;
                if (a == 'f')
                    return 5;
                if (a == 'g')
                    return 6;
                if (a == 'h')
                    return 7;
                else return -1;

            }

            //demo mode**************************
            if (mode == "1")
            {
                StreamReader f = File.OpenText("movement.txt");
                string line;
                do
                {

                    if (Console.KeyAvailable)
                    {
                        cki = Console.ReadKey(true);
                        if (cki.Key == ConsoleKey.Spacebar)
                            break;
                    }
                    line = f.ReadLine();
                    string[] spl = line.Split(' ');
                    for (int i = 1; i < 3; i++)
                    {
                        Thread.Sleep(1000);
                        if (i % 2 == 1)
                        {
                            whitemove(spl[i]);
                            Console.SetCursorPosition(45, 5 + sayac); Console.Write(sayac + 1 + "-");
                            Console.SetCursorPosition(50, 5 + sayac);
                            Console.Write(spl[i]);
                        }
                        if (i % 2 == 0)
                        {
                            blackmove(spl[i]);
                            Console.SetCursorPosition(60, 5 + sayac);
                            Console.Write(spl[i]);
                            sayac += 1;
                        }
                    }

                } while (!f.EndOfStream);


                //beyazın hareketleri
                void whitemove(string a)
                {
                    //sadece piyon 2 karakter ile notasyonda gösterilir
                    if (a.Length == 2)
                    {
                        string piece = "Wp";
                        column = converter(a[0]);
                        raw = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                        //parçayı ve gidebileceği yerleri arayan fonksiyon
                        searcher(piece);
                    }
                    //normal taş hareketi / piyon promosyonu /piyon yemesi
                    if (a.Length == 3)
                    {
                        //beyaz kingside castling
                        if (a == "0-0")
                        {
                            if (ChessPieces[7, 4] == "WK" && ChessPieces[7, 7] == "WR" && ChessPieces[7, 5] == "." && ChessPieces[7, 6] == ".")
                            {
                                ChessPieces[7, 6] = ChessPieces[7, 4];
                                ChessPieces[7, 4] = ".";
                                ChessPieces[7, 5] = ChessPieces[7, 7];
                                ChessPieces[7, 7] = ".";
                                reflesh();
                            }
                        }
                        //normal taş hareketi
                        if (a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q")
                        {
                            string piece = "W" + a[0];
                            column = converter(a[1]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[2]));
                            searcher(piece);
                        }
                    }
                    //iki taş varsa/iki piyon varsa ve yiyorsa/taş hareket eder ve şah çeker
                    if (a.Length == 4)
                    {
                        //taş hareket edip şah çekiyorsa
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[1] != 'x' && a[3] == '+')
                        {
                            string piece = "W" + a[0];
                            column = converter(a[1]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[2]));
                            searcher(piece);
                            //if(blackchecked == false) hata
                        }
                        //iki taş varsa Nbd2
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[1] != 'x' && a[3] != '+')
                        {
                            string piece = "W" + a[0];
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            if (a[1] == 'a' || a[1] == 'b' || a[1] == 'c' || a[1] == 'd' || a[1] == 'e' || a[1] == 'f' || a[1] == 'g' || a[1] == 'h')
                            {
                                int twocol = converter(a[1]);
                                searchercol(piece, twocol);
                            }
                            if (a[1] == '1' || a[1] == '2' || a[1] == '3' || a[1] == '4' || a[1] == '5' || a[1] == '6' || a[1] == '7' || a[1] == '8')
                            {
                                int tworow = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                                searcherraw(piece, tworow);
                            }


                        }
                        //iki piyon yeme hareketi
                        if ((a[0] == 'a' || a[0] == 'b' || a[0] == 'c' || a[0] == 'd' || a[0] == 'e' || a[0] == 'f' || a[0] == 'g' || a[0] == 'h') && a[1] == 'x' && a[3] != '+')
                        {
                            string piece = "Wp";
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            if (a[0] == 'a' || a[0] == 'b' || a[0] == 'c' || a[0] == 'd' || a[0] == 'e' || a[0] == 'f' || a[0] == 'g' || a[0] == 'h')
                            {
                                int twocol = converter(a[0]);
                                searchercol(piece, twocol);
                            }
                            if (a[0] == '1' || a[0] == '2' || a[0] == '3' || a[0] == '4' || a[0] == '5' || a[0] == '6' || a[0] == '7' || a[0] == '8')
                            {
                                int tworow = 8 - Convert.ToInt32(Convert.ToString(a[0]));
                                searcherraw(piece, tworow);
                            }
                        }
                        //taşların yeme harekeri(piyon hariç)
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[1] == 'x')
                        {
                            string piece = "W" + a[0];
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            //hareketin yağıldığı noktada karşı cins taş var mı?
                            if (ChessPieces[raw, column][0] == 'B')
                            {
                                searcher(piece);
                            }
                        }
                    }
                    //iki taş varsa ve şah çekiyorsa / iki taş varsa ve yiyorsa
                    if (a.Length == 5)
                    {
                        //beyaz kingside castling
                        if (a == "0-0-0")
                        {
                            if (ChessPieces[7, 4] == "WK" && ChessPieces[7, 0] == "WR" && ChessPieces[7, 1] == "." && ChessPieces[7, 2] == "." && ChessPieces[7, 3] == ".")
                            {
                                ChessPieces[7, 2] = ChessPieces[7, 4];
                                ChessPieces[7, 4] = ".";
                                ChessPieces[7, 3] = ChessPieces[7, 0];
                                ChessPieces[7, 0] = ".";
                                reflesh();
                            }
                        }
                        //iki taş varsa ve şah çekiyorsa
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[2] != 'x' && a[4] == '+')
                        {
                            string piece = "W" + a[0];
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            //hareketin yapılacağı yerde karşı renkten taş var mı kontrolü
                            if (ChessPieces[raw, column][0] == '.')
                            {
                                if (a[1] == 'a' || a[1] == 'b' || a[1] == 'c' || a[1] == 'd' || a[1] == 'e' || a[1] == 'f' || a[1] == 'g' || a[1] == 'h')
                                {
                                    int twocol = converter(a[1]);
                                    searchercol(piece, twocol);
                                }
                                if (a[1] == '1' || a[1] == '2' || a[1] == '3' || a[1] == '4' || a[1] == '5' || a[1] == '6' || a[1] == '7' || a[1] == '8')
                                {
                                    int tworow = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                                    searcherraw(piece, tworow);
                                }
                            }
                            //else hata

                        }
                        //iki taş varsa ve yiyorsa
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[2] == 'x' && a[4] != '+')
                        {
                            string piece = "W" + a[0];
                            column = converter(a[3]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[4]));
                            //hareketin yapılacağı yerde karşı renkten taş var mı kontrolü
                            if (ChessPieces[raw, column][0] == 'B')
                            {
                                if (a[1] == 'a' || a[1] == 'b' || a[1] == 'c' || a[1] == 'd' || a[1] == 'e' || a[1] == 'f' || a[1] == 'g' || a[1] == 'h')
                                {
                                    int twocol = converter(a[1]);
                                    searchercol(piece, twocol);
                                }
                                if (a[1] == '1' || a[1] == '2' || a[1] == '3' || a[1] == '4' || a[1] == '5' || a[1] == '6' || a[1] == '7' || a[1] == '8')
                                {
                                    int tworow = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                                    searcherraw(piece, tworow);
                                }
                            }

                        }

                    }
                    //en passant
                    if (a.Length == 8)
                    {
                        if ((a[0] == 'a' || a[0] == 'b' || a[0] == 'c' || a[0] == 'd' || a[0] == 'e' || a[0] == 'f' || a[0] == 'g' || a[0] == 'h') && a[6] == 'p')
                        {
                            int currentcolumn = converter(a[0]);
                            int currentraw = 3;
                            column = converter(a[2]);
                            raw = 2;
                            if (ChessPieces[raw + 1, column] == "Bp")
                            {
                                ChessPieces[raw, column] = ChessPieces[currentraw, currentcolumn];
                                ChessPieces[currentraw, currentcolumn] = ".";
                                ChessPieces[raw + 1, column] = ".";
                                reflesh();
                            }
                        }
                    }

                }

                void blackmove(string a)
                {
                    if (a.Length == 2)
                    {
                        string piece = "Bp";
                        column = converter(a[0]);
                        raw = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                        //parçayı ve gidebileceği yerleri arayan fonksiyon
                        searcher(piece);
                    }
                    //normal taş hareketi / piyon promosyonu /
                    if (a.Length == 3)
                    {
                        //siyah kingside castling
                        if (a == "0-0")
                        {
                            if (ChessPieces[0, 4] == "BK" && ChessPieces[0, 7] == "BR" && ChessPieces[0, 5] == "." && ChessPieces[0, 6] == ".")
                            {
                                ChessPieces[0, 6] = ChessPieces[0, 4];
                                ChessPieces[0, 4] = ".";
                                ChessPieces[0, 5] = ChessPieces[0, 7];
                                ChessPieces[0, 7] = ".";
                                reflesh();
                            }
                        }
                        //normal taş hareketi
                        if (a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q")
                        {
                            string piece = "B" + a[0];
                            column = converter(a[1]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[2]));
                            searcher(piece);
                        }
                    }
                    //iki taş varsa/iki piyon varsa ve yiyorsa/taş hareket eder ve şah çeker
                    if (a.Length == 4)
                    {
                        //taş hareket edip şah çekiyorsa
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[1] != 'x' && a[3] == '+')
                        {
                            string piece = "B" + a[0];
                            column = converter(a[1]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[2]));
                            searcher(piece);
                            //if(whitechecked == false) hata
                        }

                        //iki taş varsa
                        if (a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q" && a[1] != 'x' && a[3] != '+')
                        {
                            string piece = "B" + a[0];
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            if (a[1] == 'a' || a[1] == 'b' || a[1] == 'c' || a[1] == 'd' || a[1] == 'e' || a[1] == 'f' || a[1] == 'g' || a[1] == 'h')
                            {
                                int twocol = converter(a[1]);
                                searchercol(piece, twocol);
                            }
                            if (a[1] == '1' || a[1] == '2' || a[1] == '3' || a[1] == '4' || a[1] == '5' || a[1] == '6' || a[1] == '7' || a[1] == '8')
                            {
                                int tworow = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                                searcherraw(piece, tworow);
                            }
                        }
                        //iki piyon yeme hareketi
                        if ((a[0] == 'a' || a[0] == 'b' || a[0] == 'c' || a[0] == 'd' || a[0] == 'e' || a[0] == 'f' || a[0] == 'g' || a[0] == 'h') && a[1] == 'x' && a[3] != '+')
                        {
                            string piece = "Bp";
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            //notasyon hatası tespit etmek için if else komutu ile hata yazılabilir
                            if (ChessPieces[raw, column][0] == 'W')
                            {
                                if (a[0] == 'a' || a[0] == 'b' || a[0] == 'c' || a[0] == 'd' || a[0] == 'e' || a[0] == 'f' || a[0] == 'g' || a[0] == 'h')
                                {
                                    int twocol = converter(a[0]);
                                    searchercol(piece, twocol);
                                }
                                if (a[0] == '1' || a[0] == '2' || a[0] == '3' || a[0] == '4' || a[0] == '5' || a[0] == '6' || a[0] == '7' || a[0] == '8')
                                {
                                    int tworow = 8 - Convert.ToInt32(Convert.ToString(a[0]));
                                    searcherraw(piece, tworow);
                                }
                            }
                        }
                        //taşların yeme harekeri(piyon hariç)
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[1] == 'x')
                        {
                            string piece = "B" + a[0];
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            //hareketin yağıldığı noktada karşı cins taş var mı?
                            //notasyon hatası tespit etmek için if else komutu ile hata yazılabilir
                            if (ChessPieces[raw, column][0] == 'W')
                            {
                                searcher(piece);
                            }
                        }
                    }
                    //iki taş varsa ve yiyorsa / iki taş varsa ve şah çekiyorsa
                    if (a.Length == 5)
                    {
                        //siyah kingside castling
                        if (a == "0-0-0")
                        {
                            if (ChessPieces[0, 4] == "BK" && ChessPieces[0, 0] == "BR" && ChessPieces[0, 1] == "." && ChessPieces[0, 2] == "." && ChessPieces[0, 3] == ".")
                            {
                                ChessPieces[0, 2] = ChessPieces[0, 4];
                                ChessPieces[0, 4] = ".";
                                ChessPieces[0, 3] = ChessPieces[0, 0];
                                ChessPieces[0, 0] = ".";
                                reflesh();
                            }
                        }
                        //iki taş varsa ve şah çekiyorsa
                        if ((a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q") && a[2] != 'x' && a[4] == '+')
                        {
                            string piece = "B" + a[0];
                            column = converter(a[2]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[3]));
                            //hareketin yapılacağı yerde karşı renkten taş var mı kontrolü
                            if (ChessPieces[raw, column][0] == '.')
                            {
                                if (a[1] == 'a' || a[1] == 'b' || a[1] == 'c' || a[1] == 'd' || a[1] == 'e' || a[1] == 'f' || a[1] == 'g' || a[1] == 'h')
                                {
                                    int twocol = converter(a[1]);
                                    searchercol(piece, twocol);
                                }
                                if (a[1] == '1' || a[1] == '2' || a[1] == '3' || a[1] == '4' || a[1] == '5' || a[1] == '6' || a[1] == '7' || a[1] == '8')
                                {
                                    int tworow = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                                    searcherraw(piece, tworow);
                                }
                            }
                            //else hata
                        }
                        //iki taş varsa ve yiyorsa
                        if (a.Substring(0, 1) == "N" || a.Substring(0, 1) == "K" || a.Substring(0, 1) == "R" || a.Substring(0, 1) == "B" || a.Substring(0, 1) == "Q" && a[2] == 'x')
                        {
                            string piece = "B" + a[0];
                            column = converter(a[3]);
                            raw = 8 - Convert.ToInt32(Convert.ToString(a[4]));
                            //hareketin yapılacağı yerde karşı renkten taş var mı kontrolü
                            if (ChessPieces[raw, column][0] == 'W')
                            {
                                if (a[1] == 'a' || a[1] == 'b' || a[1] == 'c' || a[1] == 'd' || a[1] == 'e' || a[1] == 'f' || a[1] == 'g' || a[1] == 'h')
                                {
                                    int twocol = converter(a[1]);
                                    searchercol(piece, twocol);
                                }
                                if (a[1] == '1' || a[1] == '2' || a[1] == '3' || a[1] == '4' || a[1] == '5' || a[1] == '6' || a[1] == '7' || a[1] == '8')
                                {
                                    int tworow = 8 - Convert.ToInt32(Convert.ToString(a[1]));
                                    searcherraw(piece, tworow);
                                }
                            }

                        }

                    }
                    //en passant
                    if (a.Length == 8)
                    {
                        if ((a[0] == 'a' || a[0] == 'b' || a[0] == 'c' || a[0] == 'd' || a[0] == 'e' || a[0] == 'f' || a[0] == 'g' || a[0] == 'h') && a[6] == 'p')
                        {
                            int currentcolumn = converter(a[0]);
                            int currentraw = 4;
                            column = converter(a[2]);
                            raw = 5;
                            if (ChessPieces[raw - 1, column] == "Wp")
                            {
                                ChessPieces[raw, column] = ChessPieces[currentraw, currentcolumn];
                                ChessPieces[currentraw, currentcolumn] = ".";
                                ChessPieces[raw + 1, column] = ".";
                                reflesh();
                            }
                        }
                    }

                }
                //bulunan parçanın konumu(notasyonda verilen kordinata hareket eden taşı bulmak için)
                void searcher(string piece)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            if (ChessPieces[i, j] == piece)
                            {
                                readmover(piece, i, j);
                                Array.Clear(Playablechess, 0, 64);
                            }
                        }
                    }
                }
                void searchercol(string piece, int x)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            if (ChessPieces[i, j] == piece && j == x)
                            {
                                readmover(piece, i, j);
                                // kingcantmove();
                                Array.Clear(Playablechess, 0, 64);
                            }
                        }
                    }
                }
                void searcherraw(string piece, int x)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            if (ChessPieces[i, j] == piece && i == x)
                            {
                                readmover(piece, i, j);
                                // kingcantmove();
                                Array.Clear(Playablechess, 0, 64);
                            }
                        }
                    }
                }
                void readmover(string a, int x, int y)
                {
                    if (a.Substring(1) == "p") p(x, y);
                    if (a.Substring(1) == "N") horse(x, y);
                    if (a.Substring(1) == "K") king(x, y);
                    if (a.Substring(1) == "Q") queen(x, y);
                    if (a.Substring(1) == "B") b(x, y);
                    if (a.Substring(1) == "R") rook(x, y);

                    if (Playablechess[raw, column] == "-")
                    {
                        ChessPieces[raw, column] = ChessPieces[x, y];
                        ChessPieces[x, y] = ".";
                        reflesh();
                    }
                }

            }


            ////////////////////SONU/////////////////
            ///////// updates the variables on the screen
            void reflesh()
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        Console.SetCursorPosition(j * 5 + 6, i * 2 + 5);

                        if (((j * 5 + 6) % 2 == 0 && ((i * 2 + 5) / 2) % 2 == 0) || ((j * 5 + 6) % 2 == 1 && ((i * 2 + 5) / 2) % 2 == 1))
                            Console.BackgroundColor = ConsoleColor.White;
                        else
                            Console.BackgroundColor = ConsoleColor.Black;

                        if (ChessPieces[i, j].Substring(0, 1) == "B")
                        {
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.Write(ChessPieces[i, j].Substring(1));
                        }
                        if (ChessPieces[i, j].Substring(0, 1) == "W")
                        {

                            Console.ForegroundColor = ConsoleColor.DarkBlue;
                            Console.Write(ChessPieces[i, j].Substring(1));
                        }
                        
                        if (ChessPieces[i, j] == ".") Console.Write(" ");



                    }
                }

                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.Black;
            }


            void chesschectrans()
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (chesscheck[i, j] == null) chesscheck[i, j] = Playablechess[i, j];
                    }
                }
            }
            cursorx = 6; cursory = 5;

            while (true)
            {
                Console.SetCursorPosition(cursorx, cursory);
                if (Console.KeyAvailable)
                {       // true: there is a key in keyboard buffer

                    cki = Console.ReadKey(true);  // true: do not write character 

                    if (cki.Key == ConsoleKey.RightArrow && cursorx < 40)
                    {   // key and boundary control

                        cursorx += 5;
                    }
                    if (cki.Key == ConsoleKey.LeftArrow && cursorx > 10)
                    {
                        cursorx -= 5;
                    }
                    if (cki.Key == ConsoleKey.UpArrow && cursory > 6)
                    {
                        cursory -= 2;
                    }
                    if (cki.Key == ConsoleKey.DownArrow && cursory < 19)
                    {
                        cursory += 2;
                    }



                    if (cki.Key == ConsoleKey.H)
                    {
                        Array.Clear(Playablechess, 0, 8 * 8);
                        Array.Clear(hintarray, 0, 16);
                        string value3;
                        string y = "";
                        sayac2 = 0;
                        if (white == true) y = "W";
                        if (white == false) y = "B";
                        for (int i = 0; i < 8; i++)
                        {
                            for (int k = 0; k < 8; k++)
                            {
                                if (ChessPieces[k, i].Substring(0, 1) == y)
                                {
                                    value3 = ChessPieces[k, i].Substring(1);

                                    if (value3 == "N") horse(k, i);
                                    if (value3 == "Q") queen(k, i);
                                    if (value3 == "B") b(k, i);
                                    if (value3 == "R") rook(k, i);
                                    if (value3 == "p") p(k, i);
                                    if (value3 == "K") king(k, i);
                                    hintplay(value3);
                                    Array.Clear(Playablechess, 0, 8 * 8);
                                }
                            }
                        }
                        hintcontrol();

                    }

                    Console.BackgroundColor = ConsoleColor.Black;
                    if (cki.Key == ConsoleKey.Spacebar)
                    {

                        Array.Clear(Playablechess, 0, 8 * 8);
                        Console.SetCursorPosition(25, 25);
                        value = ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(1);
                        Console.WriteLine(value);

                        ///seçilen taşa göre fonksiyon çağırma
                        if (value == "p") p((cursory - 5) / 2, (cursorx - 6) / 5);
                        if (value == "N") horse((cursory - 5) / 2, (cursorx - 6) / 5);
                        if (value == "Q") queen((cursory - 5) / 2, (cursorx - 6) / 5);
                        if (value == "B") b((cursory - 5) / 2, (cursorx - 6) / 5);
                        if (value == "R") rook((cursory - 5) / 2, (cursorx - 6) / 5);
                        if (value == "K") king((cursory - 5) / 2, (cursorx - 6) / 5);
                        getx = ((cursory - 5) / 2);
                        gety = ((cursorx - 6) / 5);

                        //easy mode
                        if (mode == "3")
                        {
                            for (int i = 0; i < 8; i++)
                            {
                                for (int j = 0; j < 8; j++)
                                {
                                    if (Playablechess[i, j] == "-" || Playablechess[i, j] == "+" || Playablechess[i, j] == "x")
                                    {
                                        Console.SetCursorPosition(j * 5 + 6, i * 2 + 5);
                                        Console.BackgroundColor = ConsoleColor.Green;
                                        Console.WriteLine("   ");
                                    }
                                    else
                                    {
                                        if (((j * 5 + 6) % 2 == 0 && ((i * 2 + 5) / 2) % 2 == 0) || ((j * 5 + 6) % 2 == 1 && ((i * 2 + 5) / 2) % 2 == 1))
                                        {
                                            Console.SetCursorPosition(j * 5 + 6, i * 2 + 5);
                                            Console.BackgroundColor = ConsoleColor.White;
                                            Console.WriteLine("   ");
                                        }
                                        else
                                        {
                                            Console.SetCursorPosition(j * 5 + 6, i * 2 + 5);
                                            Console.BackgroundColor = ConsoleColor.Black;
                                            Console.WriteLine("   ");
                                        }
                                    }
                                }
                            }
                        }
                        reflesh();
                    }
                    // özel hareketlerin çağırılması ?
                    for (int i = 0; i < 8; i++)
                    {
                        for (int k = 0; k < 8; k++)
                        {

                            if (ChessPieces[7, k].Substring(0, 1) == "B" && ChessPieces[7, k].Substring(1) == "p")   // black promotion
                            {
                                promotion();
                            }
                            if (ChessPieces[0, k].Substring(0, 1) == "W" && ChessPieces[0, k].Substring(1) == "p")   // white promotion
                            {
                                promotion();
                            }
                        }
                    }

                    string value1 = "";

                    if (cki.Key == ConsoleKey.T)
                    {
                        if (value != "")
                        {

                            if (white == true)
                            {
                                if (white == true && ChessPieces[getx, gety].Substring(0, 1) == "W" && (Playablechess[(cursory - 5) / 2, (cursorx - 6) / 5] == "-" || Playablechess[(cursory - 5) / 2, (cursorx - 6) / 5] == "+" || Playablechess[(cursory - 5) / 2, (cursorx - 6) / 5] == "x"))
                                {
                                    ccheck = false;
                                    blackccheck = false;
                                    whiteccheck = false;
                                    string last = ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5];
                                    take((cursory - 5) / 2, (cursorx - 6) / 5, value);

                                    Array.Clear(chesscheck, 0, 64);
                                    //for short castling
                                    if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(1) == "K" && (gety - ((cursorx - 6) / 5)) == -2)
                                    {
                                        ChessPieces[7, 7] = ".";
                                        ChessPieces[7, 5] = "WR";
                                        Console.SetCursorPosition(50, 5 + sayac);
                                        Console.WriteLine("O-O  ");

                                    }
                                    //long castling
                                    else if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(1) == "K" && (gety - ((cursorx - 6) / 5)) == 2)
                                    {
                                        ChessPieces[7, 0] = ".";
                                        ChessPieces[7, 3] = "WR";
                                        Console.SetCursorPosition(50, 5 + sayac);
                                        Console.WriteLine("O-O-O ");
                                    }
                                    //En-passant
                                    else if (getx == 3 && last == "." && Math.Abs(gety - (cursorx - 6) / 5) == 1) ChessPieces[(cursory - 5) / 2 + 1, (cursorx - 6) / 5] = ".";

                                    reflesh();

                                    Array.Clear(Playablechess, 0, 8 * 8);
                                    Array.Clear(tarray, 0, 3);
                                    a1 = 0;
                                    for (int i = 0; i < 8; i++)
                                    {
                                        for (int k = 0; k < 8; k++)
                                        {
                                            if (ChessPieces[k, i].Substring(0, 1) == "W")
                                            {
                                                value1 = ChessPieces[k, i].Substring(1);
                                                if (value1 == "N") horse(k, i);
                                                if (value1 == "Q") queen(k, i);
                                                if (value1 == "B") b(k, i);
                                                if (value1 == "R") rook(k, i);
                                                if (value1 == "p") p(k, i);
                                                if (value1 == "K") king(k, i);

                                            }
                                        }
                                    }
                                    chesschectrans();


                                    white = false;
                                }
                            }
                            if (white == false)
                            {

                                if (white == false && ChessPieces[getx, gety].Substring(0, 1) == "B" && (Playablechess[(cursory - 5) / 2, (cursorx - 6) / 5] == "-" || Playablechess[(cursory - 5) / 2, (cursorx - 6) / 5] == "+" || Playablechess[(cursory - 5) / 2, (cursorx - 6) / 5] == "x"))
                                {
                                    ccheck = false;
                                    blackccheck = false;
                                    whiteccheck = false;
                                    string last = ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5];
                                    take((cursory - 5) / 2, (cursorx - 6) / 5, value);
                                    Array.Clear(chesscheck, 0, 64);
                                    //for short castling
                                    if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(1) == "K" && (gety - (cursorx - 6) / 5) == -2)
                                    {
                                        ChessPieces[0, 7] = ".";
                                        ChessPieces[0, 5] = "BR";
                                        Console.SetCursorPosition(60, 4 + sayac);

                                        Console.WriteLine("O-O  ");
                                    }
                                    //long castling
                                    else if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(1) == "K" && (gety - (cursorx - 6) / 5) == 2)
                                    {
                                        ChessPieces[0, 0] = ".";
                                        ChessPieces[0, 3] = "BR";
                                        Console.SetCursorPosition(60, 4 + sayac);

                                        Console.WriteLine("O-O-O ");
                                    }
                                    //En-passant
                                    else if (getx == 4 && last == "." && Math.Abs(gety - (cursorx - 6) / 5) == 1) ChessPieces[(cursory - 5) / 2 - 1, (cursorx - 6) / 5] = ".";

                                    reflesh();

                                    Array.Clear(Playablechess, 0, 8 * 8);
                                    Array.Clear(tarray, 0, 3);
                                    a1 = 0;
                                    for (int i = 0; i < 8; i++)
                                    {
                                        for (int k = 0; k < 8; k++)
                                        {
                                            if (ChessPieces[k, i].Substring(0, 1) == "B")
                                            {
                                                value = ChessPieces[k, i].Substring(1);

                                                ///seçilen taşa göre fonksiyon çağırma
                                                if (value == "N") horse(k, i);
                                                if (value == "Q") queen(k, i);
                                                if (value == "B") b(k, i);
                                                if (value == "R") rook(k, i);
                                                if (value == "p") p(k, i);
                                                if (value == "K") king(k, i);

                                            }
                                        }
                                    }


                                    chesschectrans();


                                    white = true;
                                }

                            }

                            ////for the castlig control
                            if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5] == "WK") count_WK++;
                            if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5] == "BK") count_BK++;
                            if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5] == "WR") { if ((cursorx - 6) / 5 == 0) count_WR1++; if ((cursorx - 6) / 5 == 7) count_WR2++; }
                            if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5] == "BR") { if ((cursorx - 6) / 5 == 0) count_BR1++; if ((cursorx - 6) / 5 == 7) count_BR2++; }

                        }
                        value = "";

                    }

                    Console.SetCursorPosition(cursorx, cursory);
                    if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(0, 1) == "B")
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                    if (ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(0, 1) == "W")
                        Console.ForegroundColor = ConsoleColor.DarkBlue;

                    Console.WriteLine(ChessPieces[(cursory - 5) / 2, (cursorx - 6) / 5].Substring(1));
                    Console.ForegroundColor = ConsoleColor.White;
                }

                Thread.Sleep(50);
            }

            void hintcontrol()
            {
                if (hintarray[0].Name == null && (whiteccheck == true || blackccheck == true))
                {
                    string champ = "";
                    if (whiteccheck == true) champ = "SİYAH";
                    if (blackccheck == true) champ = "BEYAZ";
                    Console.SetCursorPosition(10, 23);
                    Console.Write("ŞAH-MAT  " + champ + " kazandı");
                }
                if (hintarray[0].Name == null && (whiteccheck == false && blackccheck == false))
                {
                    Console.SetCursorPosition(10, 22);
                    Console.Write("Pressed H!");
                    Console.SetCursorPosition(10, 23);
                    Console.Write("OYUN BERABERE BİTTİ");
                }
                if (hintarray[1].Name == null && hintarray[0].Name != null)
                {
                    int a = 0;

                    for (int i = 0; i < 8; i++)
                    {
                        for (int k = 0; k < 8; k++)
                        {
                            Console.SetCursorPosition(10, 22);
                            Console.Write("Pressed H!");
                            Console.SetCursorPosition(10 + a * 5, 23);
                            if (hintarray[0].hitplayable[i, k] != null && a < 2) { Console.Write(hintarray[0].Name.Substring(0, 1) + Convert.ToChar(97 + k) + (8 - i)); a++; }
                        }
                    }

                }
                if (hintarray[1].Name != null && hintarray[5].Name == null)
                {
                    int a = 0;

                    for (int i = 0; i < 8; i++)
                    {
                        for (int k = 0; k < 8; k++)
                        {
                            Console.SetCursorPosition(10, 22);
                            Console.Write("Pressed H!");
                            Console.SetCursorPosition(10 + a * 5, 23);
                            if (hintarray[a].hitplayable[i, k] != null && a < 2) { Console.Write(hintarray[a].Name.Substring(0, 1) + Convert.ToChar(97 + k) + (8 - i)); a++; }
                        }
                    }
                }
                if (hintarray[1].Name != null && hintarray[5].Name != null)
                {
                    int a = 0;

                    for (int i = 0; i < 8; i++)
                    {
                        for (int k = 0; k < 8; k++)
                        {
                            Console.SetCursorPosition(10, 22);
                            Console.Write("Pressed H!");
                            Console.SetCursorPosition(10 + a * 5, 23);
                            if (a < 2) if (hintarray[(a * 5)].hitplayable[i, k] != null) { Console.Write(hintarray[a * 5].Name.Substring(0, 1) + Convert.ToChar(97 + k) + (8 - i)); a++; }
                        }
                    }
                }
            }
            void hintplay(string x)
            {
                s = 0;



                for (int i = 0; i < 8; i++)
                {
                    for (int b = 0; b < 8; b++)
                    {
                        if (Playablechess[i, b] != null && s == 0) hintarray[sayac2].hitplayable = new string[8, 8];
                        if (Playablechess[i, b] != null)
                        {
                            hintarray[sayac2].hitplayable[i, b] = Playablechess[i, b];
                            s++;
                        }
                    }

                }
                if (s != 0) { hintarray[sayac2].Name = x; sayac2++; }
            }
            void rook(int x, int y)
            {

                if (white == true && whiteccheck == true) ccheck = true;
                if (white == false && blackccheck == true) ccheck = true;
                int z = y;
                // down
                for (int i = x + 1; i <= 7; i++)
                {
                    if (ccheck == true)
                    {
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { break; }
                        for (int k = 0; k < 3; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[i, z] != " ") Playablechess[i, z] = tarray[k].merhaba[i, z];

                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[i, z] == ".") Playablechess[i, z] = "-";
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[i, z] = "#"; break; }
                        if (ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[i, z].Substring(1) == "K")
                        {
                            if (ChessPieces[i, z].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[i, z].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, z] = "+";
                            for (int k = x + 1; k <= 7; k++)
                            {
                                if (k < i) tarray[a1].merhaba[k, z] = "-";
                                if (k > i && ChessPieces[k, z] != ".") break;
                                if (k > i) Playablechess[k, z] = "-";
                            }
                            a1++;
                        }
                        if (ChessPieces[i, z] != "." && ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[i, z] = "+"; break; }
                        
                    }

                }

                //up
                for (int i = x - 1; i >= 0; i--)
                {
                    if (ccheck == true)
                    {
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { break; }
                        for (int k = 0; k < 3; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[i, z] != " ") Playablechess[i, z] = tarray[k].merhaba[i, z];

                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[i, z] == ".") Playablechess[i, z] = "-";
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[i, z] = "#"; break; }
                        if (ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[i, z].Substring(1) == "K")
                        {
                            if (ChessPieces[i, z].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[i, z].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, z] = "+";
                            for (int k = x - 1; k >= 0; k--)
                            {
                                if (k > i) tarray[a1].merhaba[k, z] = "-";
                                if (k < i && ChessPieces[k, z] != ".") break;
                                if (k < i) Playablechess[k, z] = "-";
                            }
                            a1++;
                        }
                        if (ChessPieces[i, z] != "." && ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[i, z] = "+"; break; }
                      
                    }
                }

                //left 
                for (int i = z - 1; i >= 0; i--)
                {
                    if (ccheck == true)
                    {
                        if (ChessPieces[x, i].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { break; }
                        for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x, i] != " ") Playablechess[x, i] = tarray[k].merhaba[x, i];
                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[x, i] == ".") Playablechess[x, i] = "-";
                        if (ChessPieces[x, i].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[x, i] = "#"; break; }
                        if (ChessPieces[x, i].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[x, i].Substring(1) == "K")
                        {
                            if (ChessPieces[x, i].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x, i].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, z] = "+";
                            for (int k = z - 1; k >= 0; k--)
                            {
                                if (k > i) tarray[a1].merhaba[x, k] = "-";
                                if (k < i && ChessPieces[x, k] != ".") break;
                                if (k < i) Playablechess[x, k] = "-";
                            }
                            a1++;
                        }
                        if (ChessPieces[x, i] != "." && ChessPieces[x, i].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[x, i] = "+"; break; }
                       
                    }


                }


                //right & up
                for (int i = z + 1; i <= 7; i++)
                {
                    if (ccheck == true)
                    {
                        if (ChessPieces[x,i].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { break; }
                        for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x, i] != " ") Playablechess[x, i] = tarray[k].merhaba[x, i];
                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[x, i] == ".") Playablechess[x, i] = "-";
                        if (ChessPieces[x, i].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[x, i] = "#"; break; }
                        if (ChessPieces[x, i].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[x, i].Substring(1) == "K")
                        {
                            if (ChessPieces[x, i].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x, i].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, z] = "+";
                            for (int k = z + 1; k <= 7; k++)
                            {
                                if (k < i) tarray[a1].merhaba[x, k] = "-";
                                if (k > i && ChessPieces[x, k] != ".") break;
                                if (k > i) Playablechess[x, k] = "-";
                            }
                            a1++;
                        }
                        if (ChessPieces[x, i] != "." && ChessPieces[x, i].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[x, i] = "+"; break; }
                      
                    }
                }
            }
            void b(int x, int y)
            {
                if (white == true && whiteccheck == true) ccheck = true;
                if (white == false && blackccheck == true) ccheck = true;
                int z = y;
                int j = y + 1;
                //right & down
                for (int i = x + 1; i <= 7; i++)
                {
                    z++;
                    if (z > 7) break;
                    if (ccheck == true)
                    {
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { break; }
                        for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[i, z] != " ") Playablechess[i, z] = tarray[k].merhaba[i, z];
                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[i, z] == ".") Playablechess[i, z] = "-";
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[i, z] = "#"; break; }
                        if (ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[i, z].Substring(1) == "K")
                        {
                            if (ChessPieces[i, z].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[i, z].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";

                            for (int k = x + 1; k <= 7; k++)
                            {
                                if (j > 7) break;
                                if (k < i) tarray[a1].merhaba[k, j] = "-";
                                if (k > i && ChessPieces[k, j] != ".") break;
                                if (k > i) Playablechess[k, j] = "-";
                                j++;
                            }
                            a1++;
                        }
                        if (ChessPieces[i, z] != "." && ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[i, z] = "+"; break; }
                        
                    }
                }
                z = y;
                j = y - 1;
                //left & down
                for (int i = x + 1; i <= 7; i++)
                {
                    z--;
                    if (z < 0) break;
                    if (ccheck == true)
                    {
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { break; }
                        for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[i, z] != " ") Playablechess[i, z] = tarray[k].merhaba[i, z];
                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[i, z] == ".") Playablechess[i, z] = "-";
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[i, z] = "#"; break; }
                        if (ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[i, z].Substring(1) == "K")
                        {
                            if (ChessPieces[i, z].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[i, z].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";

                            for (int k = x + 1; k <= 7; k++)
                            {
                                if (j < 0) break;
                                if (k < i) tarray[a1].merhaba[k, j] = "-";
                                if (k > i && ChessPieces[k, j] != ".") break;
                                if (k > i) Playablechess[k, j] = "-";
                                j--;
                            }
                            a1++;
                        }
                        if (ChessPieces[i, z] != "." && ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[i, z] = "+"; break; }
                        
                    }
                }
                z = y;
                j = y - 1;
                //left & up
                for (int i = x - 1; i >= 0; i--)
                {
                    z--;
                    if (z < 0) break;
                    if (ccheck == true)
                    {
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) {  break; }
                        for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[i, z] != " ") Playablechess[i, z] = tarray[k].merhaba[i, z];
                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[i, z] == ".") Playablechess[i, z] = "-";
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[i, z] = "#"; break; }
                        if (ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[i, z].Substring(1) == "K")
                        {
                            if (ChessPieces[i, z].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[i, z].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";

                            for (int k = x - 1; k >= 0; k--)
                            {
                                if (j < 0) break;
                                if (k > i) tarray[a1].merhaba[k, j] = "-";
                                if (k < i && ChessPieces[k, j] != ".") break;
                                if (k < i) Playablechess[k, j] = "-";
                                j--;
                            }
                            a1++;
                        }
                        if (ChessPieces[i, z] != "." && ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[i, z] = "+"; break; }
                       
                    }
                }
                z = y;
                j = y + 1;
                //right & up
                for (int i = x - 1; i >= 0; i--)
                {
                    z++;
                    if (z > 7) break;
                    if (ccheck == true)
                    {
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { break; }
                        for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[i, z] != " ") Playablechess[i, z] = tarray[k].merhaba[i, z];
                    }
                    if (ccheck == false)
                    {
                        if (ChessPieces[i, z] == ".") Playablechess[i, z] = "-";
                        if (ChessPieces[i, z].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) { chesscheck[i, z] = "#"; break; }
                        if (ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1) && ChessPieces[i, z].Substring(1) == "K")
                        {
                            if (ChessPieces[i, z].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[i, z].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";

                            for (int k = x - 1; k >= 0; k--)
                            {
                                if (j > 7) break;
                                if (k > i) tarray[a1].merhaba[k, j] = "-";
                                if (k < i && ChessPieces[k, j] != ".") break;
                                if (k < i) Playablechess[k, j] = "-";
                                j++;
                            }
                            a1++;
                        }
                        if (ChessPieces[i, z] != "." && ChessPieces[i, z].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) { Playablechess[i, z] = "+"; break; }
                      
                    }
                }

            }


            void queen(int x, int y)
            {
                rook(x, y);
                b(x, y);

            }

            void king(int x, int y)
            {
                if (x > 0) if ((ChessPieces[x - 1, y] == ".") && chesscheck[x - 1, y] != "-") Playablechess[x - 1, y] = "-";
                if (x > 0) if ((ChessPieces[x - 1, y] != "." && ChessPieces[x - 1, y].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x - 1, y] != "-" && chesscheck[x - 1, y] != "#") Playablechess[x - 1, y] = "+";
                if (x > 0 && y > 0) if ((ChessPieces[x - 1, y - 1] == ".") && chesscheck[x - 1, y - 1] != "-") Playablechess[x - 1, y - 1] = "-";
                if (x > 0 && y > 0) if ((ChessPieces[x - 1, y - 1] != "." && ChessPieces[x - 1, y - 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x - 1, y - 1] != "-" && chesscheck[x - 1, y - 1] != "#") Playablechess[x - 1, y - 1] = "+";
                if (x > 0 && y < 7) if ((ChessPieces[x - 1, y + 1] == ".") && chesscheck[x - 1, y + 1] != "-") Playablechess[x - 1, y + 1] = "-";
                if (x > 0 && y < 7) if ((ChessPieces[x - 1, y + 1] != "." && ChessPieces[x - 1, y + 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x - 1, y + 1] != "-" && chesscheck[x - 1, y + 1] != "#") Playablechess[x - 1, y + 1] = "+";
                if (x < 7) if ((ChessPieces[x + 1, y] == ".") && chesscheck[x + 1, y] != "-") Playablechess[x + 1, y] = "-";
                if (x < 7) if ((ChessPieces[x + 1, y] != "." && ChessPieces[x + 1, y].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x + 1, y] != "-" && chesscheck[x + 1, y] != "#") Playablechess[x + 1, y] = "+";
                if (x < 7 && y > 0) if (ChessPieces[x + 1, y - 1] == "." && chesscheck[x + 1, y - 1] != "-") Playablechess[x + 1, y - 1] = "-";
                if (x < 7 && y > 0) if ((ChessPieces[x + 1, y - 1] != "." && ChessPieces[x + 1, y - 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x + 1, y - 1] != "-" && chesscheck[x + 1, y - 1] != "#") Playablechess[x + 1, y - 1] = "+";
                if (x < 7 && y < 7) if (ChessPieces[x + 1, y + 1] == "." && chesscheck[x + 1, y + 1] != "-") Playablechess[x + 1, y + 1] = "-";
                if (x < 7 && y < 7) if ((ChessPieces[x + 1, y + 1] != "." && ChessPieces[x + 1, y + 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x + 1, y + 1] != "-" && chesscheck[x + 1, y + 1] != "#") Playablechess[x + 1, y + 1] = "+";
                if (y > 0) if ((ChessPieces[x, y - 1] == ".") && chesscheck[x, y - 1] != "-") Playablechess[x, y - 1] = "-";
                if (y > 0) if ((ChessPieces[x, y - 1] != "." && ChessPieces[x, y - 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x, y - 1] != "-" && chesscheck[x, y - 1] != "#") Playablechess[x, y - 1] = "+";
                if (y < 7) if (ChessPieces[x, y + 1] == "." && chesscheck[x, y + 1] != "-") Playablechess[x, y + 1] = "-";
                if (y < 7) if ((ChessPieces[x, y + 1] != "." && ChessPieces[x, y + 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) && chesscheck[x, y + 1] != "-" && chesscheck[x, y + 1] != "#") Playablechess[x, y + 1] = "+";

                //long castling for white
                if (ChessPieces[x, y].Substring(0, 1) == "W" && count_WK == 0 && count_WR1 == 0 && ChessPieces[7, 1] == "." && ChessPieces[7, 2] == "." && ChessPieces[7, 3] == "." &&
                    chesscheck[7, 1] != "-" && chesscheck[7, 2] != "-" && chesscheck[7, 3] != "-" && chesscheck[7, 4] != "-" && whiteccheck == false) Playablechess[7, 2] = "-";
                //short castling for white
                if (ChessPieces[x, y].Substring(0, 1) == "W" && count_WK == 0 && count_WR2 == 0 && ChessPieces[7, 6] == "." && ChessPieces[7, 5] == "." &&
                    chesscheck[7, 6] != "-" && chesscheck[7, 5] != "-" && chesscheck[7, 4] != "-" && whiteccheck == false) Playablechess[7, 6] = "-";
                //long castling for black
                if (ChessPieces[x, y].Substring(0, 1) == "B" && count_BK == 0 && count_BR1 == 0 && ChessPieces[0, 1] == "." && ChessPieces[0, 2] == "." && ChessPieces[0, 3] == "." &&
                 chesscheck[0, 1] != "-" && chesscheck[0, 2] != "-" && chesscheck[0, 3] != "-" && chesscheck[0, 4] != "-" && blackccheck == false) Playablechess[0, 2] = "-";
                //short castling for black
                if (ChessPieces[x, y].Substring(0, 1) == "B" && count_BK == 0 && count_BR2 == 0 && ChessPieces[0, 6] == "." && ChessPieces[0, 5] == "." &&
                    chesscheck[0, 6] != "-" && chesscheck[0, 5] != "-" && chesscheck[0, 4] != "-" && blackccheck == false) Playablechess[0, 6] = "-";

            }
            void horse(int x, int y)
            {

                if (white == true && whiteccheck == true) ccheck = true;
                if (white == false && blackccheck == true) ccheck = true;
                if (ccheck == true)
                {
                    if (x >= 2 && y >= 1) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x - 2, y - 1] != " ") Playablechess[x - 2, y - 1] = tarray[k].merhaba[x - 2, y - 1];
                    if (x >= 2 && y <= 6) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x - 2, y + 1] != " ") Playablechess[x - 2, y + 1] = tarray[k].merhaba[x - 2, y + 1];
                    if (x <= 5 && y >= 1) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x + 2, y - 1] != " ") Playablechess[x + 2, y - 1] = tarray[k].merhaba[x + 2, y - 1];
                    if (x <= 5 && y <= 6) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x + 2, y + 1] != " ") Playablechess[x + 2, y + 1] = tarray[k].merhaba[x + 2, y + 1];
                    if (x >= 1 && y >= 2) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x - 1, y - 2] != " ") Playablechess[x - 1, y - 2] = tarray[k].merhaba[x - 1, y - 2];
                    if (x >= 1 && y <= 5) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x - 1, y + 2] != " ") Playablechess[x - 1, y + 2] = tarray[k].merhaba[x - 1, y + 2];
                    if (x <= 6 && y >= 2) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x + 1, y - 2] != " ") Playablechess[x + 1, y - 2] = tarray[k].merhaba[x + 1, y - 2];
                    if (x <= 6 && y <= 5) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x + 1, y + 2] != " ") Playablechess[x + 1, y + 2] = tarray[k].merhaba[x + 1, y + 2];

                }
                if (ccheck == false)
                {
                    if (x >= 2 && y >= 1) if (ChessPieces[x - 2, y - 1] == ".") Playablechess[x - 2, y - 1] = "-";
                    if (x >= 2 && y >= 1) if (ChessPieces[x - 2, y - 1] != "." && ChessPieces[x - 2, y - 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x - 2, y - 1] = "+";
                    if (x >= 2 && y >= 1) if (ChessPieces[x - 2, y - 1].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x - 2, y - 1] = "#";
                    if (x >= 2 && y >= 1) if (ChessPieces[x - 2, y - 1].Substring(1) == "K" && ChessPieces[x - 2, y - 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x - 2, y - 1].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x - 2, y - 1].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }
                    if (x >= 2 && y <= 6) if (ChessPieces[x - 2, y + 1] == ".") Playablechess[x - 2, y + 1] = "-";
                    if (x >= 2 && y <= 6) if (ChessPieces[x - 2, y + 1] != "." && ChessPieces[x - 2, y + 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x - 2, y + 1] = "+";
                    if (x >= 2 && y <= 6) if (ChessPieces[x - 2, y + 1].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x - 2, y + 1] = "#";
                    if (x >= 2 && y <= 6) if (ChessPieces[x - 2, y + 1].Substring(1) == "K" && ChessPieces[x - 2, y + 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x - 2, y + 1].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x - 2, y + 1].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }
                    if (x <= 5 && y >= 1) if (ChessPieces[x + 2, y - 1] == ".") Playablechess[x + 2, y - 1] = "-";
                    if (x <= 5 && y >= 1) if (ChessPieces[x + 2, y - 1] != "." && ChessPieces[x + 2, y - 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x + 2, y - 1] = "+";
                    if (x <= 5 && y >= 1) if (ChessPieces[x + 2, y - 1].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x + 2, y - 1] = "#";
                    if (x <= 5 && y >= 1) if (ChessPieces[x + 2, y - 1].Substring(1) == "K" && ChessPieces[x + 2, y - 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x + 2, y - 1].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x + 2, y - 1].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }
                    if (x <= 5 && y <= 6) if (ChessPieces[x + 2, y + 1] == ".") Playablechess[x + 2, y + 1] = "-";
                    if (x <= 5 && y <= 6) if (ChessPieces[x + 2, y + 1] != "." && ChessPieces[x + 2, y + 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x + 2, y + 1] = "+";
                    if (x <= 5 && y <= 6) if (ChessPieces[x + 2, y + 1].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x + 2, y + 1] = "#";
                    if (x <= 5 && y <= 6) if (ChessPieces[x + 2, y + 1].Substring(1) == "K" && ChessPieces[x + 2, y + 1].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x + 2, y + 1].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x + 2, y + 1].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }

                    if (x >= 1 && y >= 2) if (ChessPieces[x - 1, y - 2] == ".") Playablechess[x - 1, y - 2] = "-";
                    if (x >= 1 && y >= 2) if (ChessPieces[x - 1, y - 2] != "." && ChessPieces[x - 1, y - 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x - 1, y - 2] = "+";
                    if (x >= 1 && y >= 2) if (ChessPieces[x - 1, y - 2].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x - 1, y - 2] = "#";
                    if (x >= 1 && y >= 2) if (ChessPieces[x - 1, y - 2].Substring(1) == "K" && ChessPieces[x - 1, y - 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x - 1, y - 2].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x - 1, y - 2].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }
                    if (x >= 1 && y <= 5) if (ChessPieces[x - 1, y + 2] == ".") Playablechess[x - 1, y + 2] = "-";
                    if (x >= 1 && y <= 5) if (ChessPieces[x - 1, y + 2] != "." && ChessPieces[x - 1, y + 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x - 1, y + 2] = "+";
                    if (x >= 1 && y <= 5) if (ChessPieces[x - 1, y + 2].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x - 1, y + 2] = "#";
                    if (x >= 1 && y <= 5) if (ChessPieces[x - 1, y + 2].Substring(1) == "K" && ChessPieces[x - 1, y + 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x - 1, y + 2].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x - 1, y + 2].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }
                    if (x <= 6 && y >= 2) if (ChessPieces[x + 1, y - 2] == ".") Playablechess[x + 1, y - 2] = "-";
                    if (x <= 6 && y >= 2) if (ChessPieces[x + 1, y - 2] != "." && ChessPieces[x + 1, y - 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x + 1, y - 2] = "+";
                    if (x <= 6 && y >= 2) if (ChessPieces[x + 1, y - 2].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x + 1, y - 2] = "#";
                    if (x <= 6 && y >= 2) if (ChessPieces[x + 1, y - 2].Substring(1) == "K" && ChessPieces[x + 1, y - 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x + 1, y - 2].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x + 1, y - 2].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }
                    if (x <= 6 && y <= 5) if (ChessPieces[x + 1, y + 2] == ".") Playablechess[x + 1, y + 2] = "-";
                    if (x <= 6 && y <= 5) if (ChessPieces[x + 1, y + 2] != "." && ChessPieces[x + 1, y + 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1)) Playablechess[x + 1, y + 2] = "+";
                    if (x <= 6 && y <= 5) if (ChessPieces[x + 1, y + 2].Substring(0, 1) == ChessPieces[x, y].Substring(0, 1)) chesscheck[x + 1, y + 2] = "#";
                    if (x <= 6 && y <= 5) if (ChessPieces[x + 1, y + 2].Substring(1) == "K" && ChessPieces[x + 1, y + 2].Substring(0, 1) != ChessPieces[x, y].Substring(0, 1))
                        {
                            if (ChessPieces[x + 1, y + 2].Substring(0, 1) == "W") whiteccheck = true;
                            if (ChessPieces[x + 1, y + 2].Substring(0, 1) == "B") blackccheck = true;
                            tarray[a1].Name = ChessPieces[x, y];
                            tarray[a1].merhaba = new string[8, 8];
                            tarray[a1].merhaba[x, y] = "+";
                            a1++;
                        }

                }


            }
            void p(int x, int y)
            {
                if (white == true && whiteccheck == true) ccheck = true;
                if (white == false && blackccheck == true) ccheck = true;

                if (ChessPieces[x, y].Substring(0, 1) == "W")
                {
                    if (ccheck == true)
                    {
                        if (y != 0) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x - 1, y - 1] != " ") Playablechess[x - 1, y - 1] = tarray[k].merhaba[x - 1, y - 1];
                        if (y != 7) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x - 1, y + 1] != " ") Playablechess[x - 1, y + 1] = tarray[k].merhaba[x - 1, y + 1];

                    }
                    if (x - 1 >= 0)
                    {
                        if (ChessPieces[x - 1, y] == ".")
                        {
                            Playablechess[x - 1, y] = "-";
                            if (x == 6 && ChessPieces[x - 2, y] == ".") Playablechess[x - 2, y] = "-";
                        }
                        if (ccheck == false)
                        {
                            if (ChessPieces[x - 1, y] == ".")
                            {
                                Playablechess[x - 1, y] = "-";
                                if (x == 6 && ChessPieces[x - 2, y] == ".") Playablechess[x - 2, y] = "-";

                            }
                            //en passant
                            if (x == 3)
                            {
                                if (y > 0 && ChessPieces[x, y - 1] == "Bp" && ChessPieces[x - 1, y - 1] == "." && filewriter[counter_hamle - 1, 2] == (Convert.ToChar(96 + y) + "" + (8 - x)).ToString()) Playablechess[x - 1, y - 1] = "x";
                                if (y < 7 && ChessPieces[x, y + 1] == "Bp" && ChessPieces[x - 1, y + 1] == "." && filewriter[counter_hamle - 1, 2] == (Convert.ToChar(98 + y) + "" + (8 - x)).ToString()) Playablechess[x - 1, y + 1] = "x";
                            }
                            if (y != 0) if (ChessPieces[x - 1, y - 1].Substring(0, 1) == "B") Playablechess[x - 1, y - 1] = "+";
                            if (y != 0) if (ChessPieces[x - 1, y - 1].Substring(0, 1) == "W") chesscheck[x - 1, y - 1] = "#";
                            if (y != 0) if (ChessPieces[x - 1, y - 1] == "BK")
                                {
                                    blackccheck = true;
                                    tarray[a1].Name = ChessPieces[x, y];
                                    tarray[a1].merhaba = new string[8, 8];
                                    tarray[a1].merhaba[x, y] = "+";
                                    a1++;
                                }
                            if (y != 7) if (ChessPieces[x - 1, y + 1].Substring(0, 1) == "B") Playablechess[x - 1, y + 1] = "+";
                            if (y != 7) if (ChessPieces[x - 1, y + 1].Substring(0, 1) == "W") chesscheck[x - 1, y + 1] = "#";
                            if (y != 7) if (ChessPieces[x - 1, y + 1] == "BK")
                                {
                                    blackccheck = true;
                                    tarray[a1].Name = ChessPieces[x, y];
                                    tarray[a1].merhaba = new string[8, 8];
                                    tarray[a1].merhaba[x, y] = "+";
                                    a1++;
                                }
                        }
                    }

                }

                if (ChessPieces[x, y].Substring(0, 1) == "B")
                {
                    if (ccheck == true)
                    {
                        if (y != 0) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x + 1, y - 1] != " ") Playablechess[x + 1, y - 1] = tarray[k].merhaba[x + 1, y - 1];
                        if (y != 7) for (int k = 0; k <= 2; k++) if (tarray[k].Name != null) if (tarray[k].merhaba[x + 1, y + 1] != " ") Playablechess[x + 1, y + 1] = tarray[k].merhaba[x + 1, y + 1];

                    }

                    if (ccheck == false)
                    {
                        if (x + 1 <= 7)
                        {
                            if (ChessPieces[x + 1, y] == ".")
                            {
                                Playablechess[x + 1, y] = "-";
                                if (x == 1 && ChessPieces[x + 2, y] == ".") Playablechess[x + 2, y] = "-";
                            }
                            //en passant
                            if (x == 4 && y > 0 && ChessPieces[4, y - 1] == "Wp" && ChessPieces[x + 1, y - 1] == "." && filewriter[counter_hamle, 1] == (Convert.ToChar(96 + y) + "" + (8 - x)).ToString()) Playablechess[x + 1, y - 1] = "x";
                            if (x == 4 && y < 7 && ChessPieces[4, y + 1] == "Wp" && ChessPieces[x + 1, y + 1] == "." && filewriter[counter_hamle, 1] == (Convert.ToChar(98 + y) + "" + (8 - x)).ToString()) Playablechess[x + 1, y + 1] = "x";

                            if (y != 0) if (ChessPieces[x + 1, y - 1].Substring(0, 1) == "W") Playablechess[x + 1, y - 1] = "+";
                            if (y != 0) if (ChessPieces[x + 1, y - 1].Substring(0, 1) == "B") chesscheck[x + 1, y - 1] = "#";
                            if (y != 0) if (ChessPieces[x + 1, y - 1] == "WK")
                                {
                                    whiteccheck = true;
                                    tarray[a1].Name = ChessPieces[x, y];
                                    tarray[a1].merhaba = new string[8, 8];
                                    tarray[a1].merhaba[x, y] = "+";
                                    a1++;
                                }
                            if (y != 7) if (ChessPieces[x + 1, y + 1].Substring(0, 1) == "W") Playablechess[x + 1, y + 1] = "+";
                            if (y != 7) if (ChessPieces[x + 1, y + 1].Substring(0, 1) == "B") chesscheck[x + 1, y + 1] = "#";
                            if (y != 7) if (ChessPieces[x + 1, y + 1] == "WK")
                                {
                                    whiteccheck = true;
                                    tarray[a1].Name = ChessPieces[x, y];
                                    tarray[a1].merhaba = new string[8, 8];
                                    tarray[a1].merhaba[x, y] = "+";
                                    a1++;
                                }
                        }
                    }
                }
            }
            void promotion()
            {
                int prom = 0;

                for (int k = 0; k < 8; k++)
                {

                    if (ChessPieces[0, k].Substring(0, 1) == "W" && ChessPieces[0, k].Substring(1) == "p")
                    {
                        prom = 1;
                        Console.SetCursorPosition(0, 21);
                        Console.WriteLine("1 : Queen");
                        Console.WriteLine("2 : Rook");
                        Console.WriteLine("3 : Bishop");
                        Console.WriteLine("4 : Knight");
                        int pnumber = Convert.ToInt32(Console.ReadLine());
                        if (pnumber == 1) { ChessPieces[0, k] = "WQ"; }
                        if (pnumber == 2) { ChessPieces[0, k] = "WR"; }
                        if (pnumber == 3) { ChessPieces[0, k] = "WB"; }
                        if (pnumber == 4) { ChessPieces[0, k] = "WN"; }
                    }
                }

                String value2 = "";
                if (prom == 1)
                {
                    prom = 0;
                    for (int i = 0; i < 8; i++)
                    {
                        for (int k = 0; k < 8; k++)
                        {
                            if (ChessPieces[k, i].Substring(0, 1) == "W")
                            {
                                value2 = ChessPieces[k, i].Substring(1);
                                if (value2 == "N") horse(k, i);
                                if (value2 == "Q") queen(k, i);
                                if (value2 == "B") b(k, i);
                                if (value2 == "R") rook(k, i);
                                if (value2 == "p") p(k, i);
                                if (value2 == "K") king(k, i);

                            }
                        }
                    }
                }


                for (int k = 0; k < 8; k++)
                {

                    if (ChessPieces[7, k].Substring(0, 1) == "B" && ChessPieces[7, k].Substring(1) == "p")
                    {
                        prom = 2;
                        Console.SetCursorPosition(0, 23);
                        Console.WriteLine("1 : Queen");
                        Console.WriteLine("2 : Rook");
                        Console.WriteLine("3 : Bishop");
                        Console.WriteLine("4 : Knight");
                        int pnumber = Convert.ToInt32(Console.ReadLine());
                        if (pnumber == 1) { ChessPieces[7, k] = "BQ"; }
                        if (pnumber == 2) { ChessPieces[7, k] = "BR"; }
                        if (pnumber == 3) { ChessPieces[7, k] = "BB"; }
                        if (pnumber == 4) { ChessPieces[7, k] = "BN"; }
                    }

                }



                value2 = "";
                if (prom == 2)
                {
                    prom = 0;
                    for (int i = 0; i < 8; i++)
                    {
                        for (int k = 0; k < 8; k++)
                        {
                            if (ChessPieces[k, i].Substring(0, 1) == "B")
                            {
                                prom = 2;
                                value2 = ChessPieces[k, i].Substring(1);
                                if (value2 == "N") horse(k, i);
                                if (value2 == "Q") queen(k, i);
                                if (value2 == "B") b(k, i);
                                if (value2 == "R") rook(k, i);
                                if (value2 == "p") p(k, i);
                                if (value2 == "K") king(k, i);

                            }
                        }
                    }
                }
                    Console.SetCursorPosition(0, 21);
                    Console.WriteLine("             ");
                    Console.WriteLine("             ");
                    Console.WriteLine("             ");
                    Console.WriteLine("             ");
                    Console.WriteLine("             ");
                }
            
            void take(int x, int y, string z)
            {
                string showpiece = "";

                if (white == true) { Console.SetCursorPosition(45, 5 + sayac); Console.Write(sayac + 1 + "-"); }
                if (white == true) Console.SetCursorPosition(50, 5 + sayac);

                if (white == false)
                {
                    Console.SetCursorPosition(60, 5 + sayac);
                    sayac += 1;
                }
                if (Playablechess[x, y] == "-")
                {
                    if (ChessPieces[getx, gety].Substring(1) != "p") showpiece = ChessPieces[getx, gety].Substring(1);
                    Console.Write(showpiece + Convert.ToChar(97 + y) + (8 - x));
                    if (white == true) filewriter[counter_hamle, 1] = showpiece + Convert.ToChar(97 + y) + (8 - x);
                    if (white == false)
                    {
                        filewriter[counter_hamle, 2] = showpiece + Convert.ToChar(97 + y) + (8 - x);
                        counter_hamle++;
                    }
                }
                if (Playablechess[x, y] == "x")
                {
                    Console.Write(Convert.ToChar(97 + gety) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x) + "e.p.");
                    if (white == true) filewriter[counter_hamle, 1] = Convert.ToChar(97 + gety) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x) + "e.p.";
                    if (white == false)
                    {
                        filewriter[counter_hamle, 2] = Convert.ToChar(97 + gety) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x) + "e.p.";
                        counter_hamle++;
                    }
                }

                if (Playablechess[x, y] == "+")
                {
                    if (ChessPieces[getx, gety].Substring(1) != "p")
                    {
                        Console.Write(ChessPieces[getx, gety].Substring(1) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x));
                        if (white == true) filewriter[counter_hamle, 1] = (ChessPieces[getx, gety].Substring(1) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x));
                        if (white == false)
                        {
                            filewriter[counter_hamle, 2] = (ChessPieces[getx, gety].Substring(1) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x));
                            counter_hamle++;
                        }
                    }
                    if (ChessPieces[getx, gety].Substring(1) == "p")
                    {
                        Console.Write(Convert.ToChar(97 + gety) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x));
                        if (white == true) filewriter[counter_hamle, 1] = Convert.ToChar(97 + gety) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x);
                        if (white == false)
                        {
                            filewriter[counter_hamle, 2] = Convert.ToChar(97 + gety) + "x" + showpiece + Convert.ToChar(97 + y) + (8 - x);
                            counter_hamle++;
                        }
                    }

                }
                ChessPieces[x, y] = ChessPieces[getx, gety];
                ChessPieces[getx, gety] = ".";

                reflesh();
            }


            // Console.ReadKey();
        }
    }
}